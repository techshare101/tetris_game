export const TETROMINOS = {
    I: {
      shape: [[1, 1, 1, 1]],
      color: '#00f0f0'
    },
    J: {
      shape: [
        [1, 0, 0],
        [1, 1, 1]
      ],
      color: '#0000f0'
    },
    L: {
      shape: [
        [0, 0, 1],
        [1, 1, 1]
      ],
      color: '#f0a000'
    },
    O: {
      shape: [
        [1, 1],
        [1, 1]
      ],
      color: '#f0f000'
    },
    S: {
      shape: [
        [0, 1, 1],
        [1, 1, 0]
      ],
      color: '#00f000'
    },
    T: {
      shape: [
        [0, 1, 0],
        [1, 1, 1]
      ],
      color: '#a000f0'
    },
    Z: {
      shape: [
        [1, 1, 0],
        [0, 1, 1]
      ],
      color: '#f00000'
    }
  };

  export const randomTetromino = () => {
    const pieces = 'IJLOSTZ';
    const randPiece = pieces[Math.floor(Math.random() * pieces.length)];
    return TETROMINOS[randPiece];
  };
