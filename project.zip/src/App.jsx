import React, { useState } from 'react';
  import TodoList from './components/TodoList';
  import TodoForm from './components/TodoForm';

  function App() {
    const [todos, setTodos] = useState([]);

    const addTodo = (text) => {
      const newTodos = [...todos, { text, completed: false }];
      setTodos(newTodos);
    };

    const removeTodo = (index) => {
      const newTodos = todos.filter((_, i) => i !== index);
      setTodos(newTodos);
    };

    return (
      <div className="app">
        <h1>Todo App</h1>
        <TodoForm addTodo={addTodo} />
        <TodoList todos={todos} removeTodo={removeTodo} />
      </div>
    );
  }

  export default App;
