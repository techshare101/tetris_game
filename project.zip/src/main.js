import { TETROMINOS, randomTetromino } from './tetrominos.js';

  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const BLOCK_SIZE = 20;
  const BOARD_WIDTH = canvas.width / BLOCK_SIZE;
  const BOARD_HEIGHT = canvas.height / BLOCK_SIZE;

  let dropCounter = 0;
  let dropInterval = 1000;
  let lastTime = 0;
  let score = 0;
  let level = 1;
  
  const scoreElement = document.getElementById('score');
  const levelElement = document.getElementById('level');

  // Create the game board
  let board = Array(BOARD_HEIGHT).fill().map(() => Array(BOARD_WIDTH).fill(0));

  // Player state
  const player = {
    pos: { x: 0, y: 0 },
    piece: null,
    score: 0,
  };

  function createPiece() {
    const piece = randomTetromino();
    player.piece = piece;
    player.pos.y = 0;
    player.pos.x = Math.floor(BOARD_WIDTH / 2) - Math.floor(piece.shape[0].length / 2);

    // Game Over check
    if (collide()) {
      board = Array(BOARD_HEIGHT).fill().map(() => Array(BOARD_WIDTH).fill(0));
      score = 0;
      level = 1;
      updateScore();
    }
  }

  function collide() {
    const piece = player.piece.shape;
    for (let y = 0; y < piece.length; y++) {
      for (let x = 0; x < piece[y].length; x++) {
        if (piece[y][x] !== 0 &&
            (board[y + player.pos.y] &&
            board[y + player.pos.y][x + player.pos.x]) !== 0) {
          return true;
        }
      }
    }
    return false;
  }

  function merge() {
    player.piece.shape.forEach((row, y) => {
      row.forEach((value, x) => {
        if (value !== 0) {
          board[y + player.pos.y][x + player.pos.x] = player.piece.color;
        }
      });
    });
  }

  function rotate() {
    const piece = player.piece.shape;
    const newPiece = piece[0].map((_, i) => piece.map(row => row[i]).reverse());
    const pos = player.pos.x;
    let offset = 1;

    player.piece.shape = newPiece;

    while (collide()) {
      player.pos.x += offset;
      offset = -(offset + (offset > 0 ? 1 : -1));
      if (offset > piece[0].length) {
        player.piece.shape = piece;
        player.pos.x = pos;
        return;
      }
    }
  }

  function playerDrop() {
    player.pos.y++;
    if (collide()) {
      player.pos.y--;
      merge();
      clearLines();
      createPiece();
    }
    dropCounter = 0;
  }

  function playerMove(dir) {
    player.pos.x += dir;
    if (collide()) {
      player.pos.x -= dir;
    }
  }

  function clearLines() {
    let linesCleared = 0;
    
    outer: for (let y = board.length - 1; y > 0; y--) {
      for (let x = 0; x < board[y].length; x++) {
        if (board[y][x] === 0) {
          continue outer;
        }
      }

      const row = board.splice(y, 1)[0].fill(0);
      board.unshift(row);
      y++;
      linesCleared++;
    }

    if (linesCleared > 0) {
      score += linesCleared * 100 * level;
      level = Math.floor(score / 1000) + 1;
      dropInterval = Math.max(100, 1000 - (level * 100));
      updateScore();
    }
  }

  function updateScore() {
    scoreElement.textContent = score;
    levelElement.textContent = level;
  }

  function draw() {
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw board
    board.forEach((row, y) => {
      row.forEach((value, x) => {
        if (value) {
          ctx.fillStyle = value;
          ctx.fillRect(x * BLOCK_SIZE, y * BLOCK_SIZE, BLOCK_SIZE - 1, BLOCK_SIZE - 1);
        }
      });
    });

    // Draw current piece
    if (player.piece) {
      player.piece.shape.forEach((row, y) => {
        row.forEach((value, x) => {
          if (value) {
            ctx.fillStyle = player.piece.color;
            ctx.fillRect(
              (x + player.pos.x) * BLOCK_SIZE,
              (y + player.pos.y) * BLOCK_SIZE,
              BLOCK_SIZE - 1,
              BLOCK_SIZE - 1
            );
          }
        });
      });
    }
  }

  function update(time = 0) {
    const deltaTime = time - lastTime;
    lastTime = time;
    dropCounter += deltaTime;

    if (dropCounter > dropInterval) {
      playerDrop();
    }

    draw();
    requestAnimationFrame(update);
  }

  document.addEventListener('keydown', event => {
    switch (event.key) {
      case 'ArrowLeft':
        playerMove(-1);
        break;
      case 'ArrowRight':
        playerMove(1);
        break;
      case 'ArrowDown':
        playerDrop();
        break;
      case 'ArrowUp':
        rotate();
        break;
      case ' ':
        while (!collide()) {
          player.pos.y++;
        }
        player.pos.y--;
        merge();
        clearLines();
        createPiece();
        break;
    }
  });

  createPiece();
  update();
